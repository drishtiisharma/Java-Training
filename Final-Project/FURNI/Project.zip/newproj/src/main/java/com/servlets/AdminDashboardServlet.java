package com.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.AdminDao;
import com.daoimpl.AdminDaoImpl;
import com.pojo.Customer;
import com.pojo.Order;
import com.pojo.Product;
import com.pojo.DBConnection;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection conn = null;

        try {
            // Get database connection
            conn = DBConnection.getConnection();

            // Initialize DAO
            AdminDaoImpl dao = new AdminDaoImpl(conn);

            // Fetch statistics
            int totalUsers = dao.getTotalUsers();
            int totalProducts = dao.getTotalProducts();
            int totalOrders = dao.getTotalOrders();
            double totalRevenue = dao.getTotalRevenue();

            // Fetch recent data
            List<Customer> recentCustomers = dao.getRecentCustomers();
            List<Order> recentOrders = dao.getRecentOrders();
            List<Product> lowStockProducts = dao.getLowStockProducts();

            // Set attributes for JSP
            request.setAttribute("totalUsers", totalUsers);
            request.setAttribute("totalProducts", totalProducts);
            request.setAttribute("totalOrders", totalOrders);
            request.setAttribute("totalRevenue", totalRevenue);
            request.setAttribute("recentCustomers", recentCustomers);
            request.setAttribute("recentOrders", recentOrders);
            request.setAttribute("lowStockProducts", lowStockProducts);

           

            // Forward to JSP
            request.getSession().setAttribute("activePage", "dashboard");
            RequestDispatcher rd = request.getRequestDispatcher("admin-dashboard.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading dashboard.");
        } finally {
            try {
                if (conn != null && !conn.isClosed()) conn.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
