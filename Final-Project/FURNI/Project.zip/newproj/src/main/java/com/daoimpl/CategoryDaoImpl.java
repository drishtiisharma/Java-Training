package com.daoimpl;

import com.dao.CategoryDao;
import com.pojo.Category;

import java.sql.*;
import java.util.*;

public class CategoryDaoImpl implements CategoryDao {
    private Connection conn;

    public CategoryDaoImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public boolean addCategory(Category c) {
        try {
            String sql = "INSERT INTO category (cid, category_name, category_description) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, c.getCid());
            ps.setString(2, c.getCategory_name());
            ps.setString(3, c.getCategory_description());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    @Override
    public boolean updateCategory(Category c) {
        try {
            String sql = "UPDATE category SET category_name=?, category_description=? WHERE cid=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getCategory_name());
            ps.setString(2, c.getCategory_description());
            ps.setInt(3, c.getCid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
    @Override
    public boolean deleteCategory(int cid) {
        String sql = "DELETE FROM category WHERE cid = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cid);
            int affectedRows = ps.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    @Override
    public Category getCategoryById(int cid) {
        try {
            String sql = "SELECT * FROM category WHERE cid=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, cid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Category(
                    rs.getInt("cid"),
                    rs.getString("category_name"),
                    rs.getString("category_description")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Category> getAllCategories() {
        List<Category> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM category";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Category(
                    rs.getInt("cid"),
                    rs.getString("category_name"),
                    rs.getString("category_description")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
