package com.servlets;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.daoimpl.ProductDaoImpl;
import com.pojo.Product;

@WebServlet("/AddProductServlet")
@MultipartConfig
public class AddProductServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            // 1. Load JDBC driver and get connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/furni", "root", "root");

            // 2. Retrieve form data
            String pname = request.getParameter("pname");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            int cid = Integer.parseInt(request.getParameter("cid"));

            // 3. Image Upload
            Part filePart = request.getPart("productImage");
            String imageFileName = filePart.getSubmittedFileName();

            // 4. Save image to folder
            String uploadPath = getServletContext().getRealPath("/images") + File.separator + imageFileName;
            File uploadDir = new File(getServletContext().getRealPath("/images"));
            if (!uploadDir.exists()) uploadDir.mkdir();

            try (FileOutputStream fos = new FileOutputStream(uploadPath);
                 InputStream is = filePart.getInputStream()) {
                byte[] data = new byte[is.available()];
                is.read(data);
                fos.write(data);
            }

            // 5. Create Product object
            Product product = new Product();
            product.setPname(pname);
            product.setDescription(description);
            product.setPrice(price);
            product.setQuantity(quantity);
            product.setCid(cid);
            product.setImage_url(imageFileName);

            // 6. Insert product into DB
            ProductDaoImpl dao = new ProductDaoImpl(con);
            boolean result = dao.addProduct(product);

            // 7. Set feedback message
            request.setAttribute("msg", result ? "✅ Product added successfully!" : "❌ Failed to add product!");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg", "⚠ Error: " + e.getMessage());
        }

        // 8. Forward to addproduct.jsp
        RequestDispatcher rd = request.getRequestDispatcher("addproduct.jsp");
        rd.forward(request, response);
    }
}
