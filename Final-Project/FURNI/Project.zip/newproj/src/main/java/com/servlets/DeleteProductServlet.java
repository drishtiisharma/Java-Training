package com.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;

import com.daoimpl.ProductDaoImpl;

@WebServlet("/DeleteProductServlet")
public class DeleteProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Step 1: Load Driver and Create Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/furni", "root", "root");

            // Step 2: Create DAO object
            ProductDaoImpl dao = new ProductDaoImpl(con);

            // Step 3: Read Product ID from request
            String pidStr = request.getParameter("pid");
            int pid = Integer.parseInt(pidStr);

            // Step 4: Delete product
            boolean success = dao.deleteProduct(pid);

            // Step 5: Set session message
            HttpSession session = request.getSession();
            if (success) {
                session.setAttribute("msg", "Product deleted successfully!");
            } else {
                session.setAttribute("msg", "Failed to delete the product!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            HttpSession session = request.getSession();
            session.setAttribute("msg", "Error occurred: " + e.getMessage());
        }

        // Step 6: Redirect to product list
        response.sendRedirect(request.getContextPath() + "/product.jsp");
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response); // delegate to doPost
    }

}
