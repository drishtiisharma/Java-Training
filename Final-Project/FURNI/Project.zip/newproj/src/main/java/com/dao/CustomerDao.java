package com.dao;

import com.pojo.Customer;
import java.util.List;

public interface CustomerDao {

    Customer getCustomerByUsername(String username);
    boolean updateCustomer(Customer customer);
    List<Customer> getAllCustomers();
    List<Customer> getRecentCustomers(int limit);
    String getCustomerStatus(String username);
    boolean updateCustomerStatus(String username, String newStatus);

    int getOrderCountByUsername(String username);
    double getTotalSpentByUsername(String username);
    String getLastOrderDateByUsername(String username);
    String getCustomerSinceDateByUsername(String username);
   
       
        
        // New method to get customer status by username
        String getCustomerStatusByUsername(String username);
        List<Customer> searchCustomers(String keyword);
// Add this method
        

}
