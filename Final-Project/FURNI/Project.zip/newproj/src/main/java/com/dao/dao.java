package com.dao;

import java.util.List;

import com.pojo.UserInfo;

public interface dao {
	
    boolean addUser(UserInfo u);
    boolean updateUser(UserInfo u);
    boolean deleteUser(String email);
    UserInfo getUserByLoginCredential(String credential, String password);
    List<UserInfo> getAllUsers();
    boolean isUsernameExists(String username);
    boolean isEmailExists(String email);
    public UserInfo getUserByUsername(String username);
    int countMembersAddedBy(String adminUsername);

    public int countUsersAddedBy(String adminUsername);
    public List<UserInfo> getUsersAddedBy(String adminUsername);
    List<UserInfo> getMembersAddedByAdmin(String addedByUsername);
    boolean insertUser(UserInfo user);
    boolean deleteUserByUsernameAndAddedBy(String username, String addedBy);
    boolean isEmailExistsinadmin(String email);
    boolean updateUserByEmail(String oldEmail, UserInfo user);
    boolean updateUserinadmin(UserInfo user);
    boolean updatePasswordById(int id, String newPassword);
    boolean updateUserSecurity(int id, String question, String answer);
    boolean updateSecurityQuestion(int userId, String question, String answer);
    boolean registerCustomer(UserInfo user);
    public boolean updateUserProfile(int userId, String phone, String address, String securityQuestion, String securityAnswer) ;

    boolean updateCustomerProfile(UserInfo customer);
    public boolean updateUserProfile(int id, String username, String email, String phone, String address, String securityQuestion, String securityAnswer, String imagePath);
    public boolean updatePasswordAndSecurity(int id, String password, String question, String answer);
    public UserInfo getUserById(int id);
    boolean updatePassword(String email, String newPassword);
    public boolean setSecurityQuestionAnswer(int id, String question, String answer) ;





}