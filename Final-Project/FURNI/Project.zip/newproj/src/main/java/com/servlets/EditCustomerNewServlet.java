package com.servlets;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

@WebServlet("/EditCustomerNewServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
                 maxFileSize = 1024 * 1024 * 10,       // 10MB
                 maxRequestSize = 1024 * 1024 * 50)    // 50MB
public class EditCustomerNewServlet extends HttpServlet {

    private dao userDao = new daoimpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        UserInfo user = (UserInfo) session.getAttribute("loggedInUser");

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Get form data
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");

        Part filePart = request.getPart("image");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String imagePath = user.getImage(); // Keep existing image if no new image uploaded

        if (fileName != null && !fileName.isEmpty()) {
            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads" + File.separator + "customers";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            String fileSavePath = uploadPath + File.separator + fileName;
            filePart.write(fileSavePath);

            imagePath = "uploads/customers/" + fileName; // Store relative path
        }

        // Update user object
        user.setUsername(username);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);
        user.setImage(imagePath);

        // DAO update
        boolean success = userDao.updateUser(user);

        if (success) {
            session.setAttribute("loggedInUser", user); // Refresh session data
            response.sendRedirect("MyProfile.jsp?update=success");
        } else {
            request.setAttribute("error", "Failed to update profile.");
            request.getRequestDispatcher("editcustomernew.jsp").forward(request, response);
        }
    }
}
