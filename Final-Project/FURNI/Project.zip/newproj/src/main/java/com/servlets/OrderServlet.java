package com.servlets;

import com.pojo.UserInfo;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            // Not logged in, redirect to login page
            response.sendRedirect("login.jsp?reason=not_logged_in");
            return;
        }

        // Get logged in user info from session
        UserInfo loggedInUser = (UserInfo) session.getAttribute("loggedInUser");

        // If you want fresh data from DB, you can fetch user again here using DAO
        // Example:
        // daoimpl dao = new daoimpl();
        // UserInfo user = dao.getUserByUsername(loggedInUser.getUsername());
        // request.setAttribute("customer", user);

        // Otherwise just forward session user
        request.setAttribute("customer", loggedInUser);

        // Forward to profile JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("MyOrders.jsp"); // Your JSP name
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Forward POST to GET for this servlet (optional)
        doGet(request, response);
    }
}
