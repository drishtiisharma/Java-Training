package com.pojo;

public class Product {
    private int pid;
    private String pname;
    private String description;
    private double price;
    private int quantity;
    private String image_url;
    private int cid;
   
    private String category_name;
    private String category_description;


    public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getCategory_description() {
		return category_description;
	}

	public Product(int pid, String pname, String description, double price, int quantity, String image_url, int cid,
			String category_name, String category_description) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
		this.image_url = image_url;
		this.cid = cid;
		this.category_name = category_name;
		this.category_description = category_description;
	}

	public void setCategory_description(String category_description) {
		this.category_description = category_description;
	}

	public Product() {}

  

	public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }
}