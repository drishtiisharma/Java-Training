package com.servlets;
import com.dao.CustomerDao;
import com.daoimpl.CustomerDaoImpl;
import com.pojo.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/ViewCustomerInAdminServlet")
public class ViewCustomerInAdminServlet extends HttpServlet {
    
    // Define serialVersionUID to prevent warning
    private static final long serialVersionUID = 1L;

    private CustomerDao customerDao;

    @Override
    public void init() throws ServletException {
        customerDao = new CustomerDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");

        // Fetch customer details from the database
        Customer customer = customerDao.getCustomerByUsername(username);

        if (customer != null) {
            // Set the customer object as a request attribute
            request.setAttribute("customer", customer);

            // Forward to JSP for displaying customer details
            request.getRequestDispatcher("viewCustomerInAdmin.jsp").forward(request, response);
        } else {
            // If customer not found, redirect to the error page or show a message
            response.sendRedirect("AdminCustomerInAdminServlet?error=CustomerNotFound");
        }
    }
}
