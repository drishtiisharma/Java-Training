package com.dao;

import com.pojo.Order;
import com.pojo.OrderItem;
import java.util.List;

public interface OrderDao {
    int createOrder(Order order) throws Exception;

    boolean addOrderItem(OrderItem item) throws Exception;

    List<Order> getOrdersByUser(String username) throws Exception;

    List<Order> getOrdersByUsername(String username) throws Exception;

    List<Order> getRecentOrders(int limit) throws Exception;

    List<Order> getAllOrders() throws Exception;

    Order getOrderWithItems(int orderId) throws Exception;

    List<OrderItem> getOrderItemsByOrderId(int orderId) throws Exception;

    int getTotalOrders();

    int getPendingOrders();

    int getProcessingOrders();

    int getDeliveredOrders();

    boolean updateOrderStatus(int orderId, String status);
}
