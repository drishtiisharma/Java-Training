package com.servlets;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/EditProfileServlet")
@MultipartConfig
public class EditProfileServlet extends HttpServlet {

    private dao userDao;

    @Override
    public void init() {
        userDao = new daoimpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        UserInfo admin = (UserInfo) session.getAttribute("loggedInUser");
        req.setAttribute("admin", admin);
        req.getRequestDispatcher("editProfile.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        UserInfo admin = (UserInfo) session.getAttribute("loggedInUser");

        String username = req.getParameter("username").trim();
        String email = req.getParameter("email").trim();
        String phone = req.getParameter("phone").trim();
        String address = req.getParameter("address").trim();

        // Handle image upload
        Part imagePart = req.getPart("imageFile");
        String fileName = imagePart.getSubmittedFileName();
        String imagePath = admin.getImage();

        if (fileName != null && !fileName.isEmpty()) {
            String realPath = getServletContext().getRealPath("/images");
            File uploadDir = new File(realPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            String fullPath = realPath + File.separator + fileName;
            try (FileOutputStream fos = new FileOutputStream(fullPath);
                 InputStream is = imagePart.getInputStream()) {
                byte[] buffer = new byte[is.available()];
                is.read(buffer);
                fos.write(buffer);
                imagePath = "images/" + fileName;
            }
        }

        // Check for email conflict
        if (!email.equalsIgnoreCase(admin.getEmail()) && userDao.isEmailExistsinadmin(email)) {
            req.setAttribute("error", "Email already exists.");
            req.setAttribute("admin", admin);
            req.getRequestDispatcher("editProfile.jsp").forward(req, resp);
            return;
        }

        // Update admin object
        admin.setUsername(username);
        admin.setEmail(email);
        admin.setPhone(phone.isEmpty() ? null : phone);
        admin.setAddress(address.isEmpty() ? null : address);
        admin.setImage(imagePath);

        boolean success = userDao.updateUserinadmin(admin);
        if (success) {
            session.setAttribute("loggedInUser", admin);
            session.setAttribute("successMessage", "Profile updated successfully.");
            resp.sendRedirect("AdminProfileServlet");
        } else {
            req.setAttribute("error", "Failed to update profile.");
            req.setAttribute("admin", admin);
            req.getRequestDispatcher("editProfile.jsp").forward(req, resp);
        }
    }
}
