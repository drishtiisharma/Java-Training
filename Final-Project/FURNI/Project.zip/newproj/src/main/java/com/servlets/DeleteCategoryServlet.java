package com.servlets;

import com.dao.CategoryDao;
import com.daoimpl.CategoryDaoImpl;
import com.pojo.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/DeleteCategory")
public class DeleteCategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String cidStr = request.getParameter("cid");
            if (cidStr != null) {
                int cid = Integer.parseInt(cidStr);
                CategoryDao dao = new CategoryDaoImpl(DBConnection.getConnection());
                dao.deleteCategory(cid);
            }
            // Redirect back to category list after deletion (or if cid was null)
            response.sendRedirect(request.getContextPath() + "/CategoryServlet");
        } catch (NumberFormatException e) {
            // Handle invalid integer format for cid param
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/CategoryServlet?error=invalidId");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/CategoryServlet?error=deletionFailed");
        }
    }

    // Optionally override doPost if you want to allow POST for deletion
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
