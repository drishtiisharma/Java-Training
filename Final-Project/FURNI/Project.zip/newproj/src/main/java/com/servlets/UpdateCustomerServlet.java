package com.servlets;

import com.dao.CustomerDao;
import com.daoimpl.CustomerDaoImpl;
import com.pojo.Customer;
import com.pojo.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;

@WebServlet("/UpdateCustomerServlet")
public class UpdateCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8"); // Handle Unicode input
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");

        // Input validation
        if (username == null || email == null || phone == null || address == null ||
            username.trim().isEmpty() || email.trim().isEmpty() ||
            phone.trim().isEmpty() || address.trim().isEmpty()) {

            response.sendRedirect("edit-customer.jsp?username=" + username + "&error=MissingFields");
            return;
        }

        Customer customer = new Customer();
        customer.setUsername(username);
        customer.setEmail(email);
        customer.setPhone(phone);
        customer.setAddress(address);

        try (Connection conn = DBConnection.getConnection()) {
            CustomerDao dao = new CustomerDaoImpl(conn);
            boolean updated = dao.updateCustomer(customer);

            if (updated) {
                response.sendRedirect("AdminCustomerServlet?message=CustomerUpdated");
            } else {
                response.sendRedirect("edit-customer.jsp?username=" + username + "&error=UpdateFailed");
            }

        } catch (Exception e) {
            e.printStackTrace(); // Log to server
            // Optional: pass error message as query param
            response.sendRedirect("error.jsp?msg=DatabaseConnectionFailed");
        }
    }
}
