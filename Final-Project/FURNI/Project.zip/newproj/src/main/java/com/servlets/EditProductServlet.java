package com.servlets;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.daoimpl.ProductDaoImpl;
import com.pojo.Product;

@WebServlet("/EditProductServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2,
                 maxFileSize = 1024 * 1024 * 10,
                 maxRequestSize = 1024 * 1024 * 50)
public class EditProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/furni";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "root";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
            ProductDaoImpl dao = new ProductDaoImpl(con);

            int pid = Integer.parseInt(request.getParameter("pid"));
            String pname = request.getParameter("pname");
            String description = request.getParameter("description");
            double price = Double.parseDouble(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            int cid = Integer.parseInt(request.getParameter("cid"));
            String oldImage = request.getParameter("oldImage");

            Part filePart = request.getPart("productImage");
            String imageFileName = filePart.getSubmittedFileName();
            String imageToUse = oldImage;

            if (imageFileName != null && !imageFileName.trim().isEmpty()) {
                imageToUse = imageFileName;

                String uploadPath = getServletContext().getRealPath("/images") + File.separator + imageFileName;
                File uploadDir = new File(getServletContext().getRealPath("/images"));
                if (!uploadDir.exists()) uploadDir.mkdirs();

                try (InputStream is = filePart.getInputStream();
                     FileOutputStream fos = new FileOutputStream(uploadPath)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = is.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                    }
                }
            }

            Product product = new Product();
            product.setPid(pid);
            product.setPname(pname);
            product.setDescription(description);
            product.setPrice(price);
            product.setQuantity(quantity);
            product.setCid(cid);
            product.setImage_url(imageToUse);

            boolean result = dao.updateProduct(product);

            if (result) {
                session.setAttribute("msg", "✅ Product updated successfully!");
            } else {
                session.setAttribute("msg", "❌ Failed to update product.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("msg", "⚠️ Error: " + e.getMessage());
        } finally {
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }

        response.sendRedirect("product.jsp");
    }
}
