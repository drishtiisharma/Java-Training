package com.servlets;

import com.daoimpl.ProductDaoImpl;
import com.pojo.Product;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Track active page in session (optional UI logic)
        HttpSession session = request.getSession();
        session.setAttribute("currentPage", "shop");

        // Get search query and category
        String query = request.getParameter("query");
        String categoryParam = request.getParameter("category");

        if (query == null) query = "";
        query = query.trim();

        int cid = -1;
        try {
            if (categoryParam != null && !categoryParam.equalsIgnoreCase("all")) {
                cid = Integer.parseInt(categoryParam);
            }
        } catch (NumberFormatException e) {
            cid = -1; // fallback in case of invalid input
        }

        List<Product> resultList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/furni", "root", "root")) {
                ProductDaoImpl dao = new ProductDaoImpl(con);

                // Determine search logic
                if (cid > 0 && !query.isEmpty()) {
                    resultList = dao.searchProductsByNameAndCategory(query, cid);
                } else if (cid > 0) {
                    resultList = dao.getProductsByCategory(cid);
                } else if (!query.isEmpty()) {
                    resultList = dao.searchProductsByName(query);
                } else {
                    resultList = dao.getAllProducts();
                }

                // Set results for JSP
                request.setAttribute("results", resultList);
                request.setAttribute("searchQuery", query);
                request.setAttribute("category", categoryParam);
                request.getRequestDispatcher("search.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Search error: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
