package com.servlets;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private dao userDao = new daoimpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        String address = request.getParameter("address");

        // Optional: Validate input here

        // Create UserInfo object and set values
        UserInfo user = new UserInfo();
        user.setUsername(username);
        user.setEmail(email);
        user.setPhone(phone);
        user.setPassword(password);
        user.setAddress(address);
        user.setImage(""); // Optional: If you have an image, set it here
        user.setRole("customer");

        // Call the method to register customer
        boolean isRegistered = userDao.registerCustomer(user);

        if (isRegistered) {
            // Registration successful, redirect to login page
            request.setAttribute("message", "Registration successful. Please log in.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            // Registration failed, show error message
            request.setAttribute("error", "Registration failed. Please try again.");
            request.getRequestDispatcher("registration.jsp").forward(request, response);
        }
    }
}
