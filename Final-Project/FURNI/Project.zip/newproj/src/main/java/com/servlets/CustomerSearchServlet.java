package com.servlets;

import com.dao.CategoryDao;
import com.dao.ProductDao;
import com.daoimpl.CategoryDaoImpl;
import com.daoimpl.ProductDaoImpl;
import com.pojo.Category;
import com.pojo.DBConnection;
import com.pojo.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/CustomerSearchServlet")
public class CustomerSearchServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String query = request.getParameter("query");
        String category = request.getParameter("category");

        ProductDao productDao = new ProductDaoImpl(DBConnection.getConnection());
        CategoryDao categoryDao = new CategoryDaoImpl(DBConnection.getConnection());

        List<Product> searchResults;
        if (category != null && !category.equalsIgnoreCase("all")) {
            searchResults = productDao.searchProductsByCategoryAndName(category, query);

        } else {
            searchResults = productDao.searchProductsByName(query);
        }

        List<Category> categories = categoryDao.getAllCategories();

        request.setAttribute("searchResults", searchResults);
        request.setAttribute("categoryList", categories);
        request.setAttribute("query", query);
        request.setAttribute("selectedCategory", category);
        request.getRequestDispatcher("search-results.jsp").forward(request, response);
    }
}
