package com.dao;

import com.pojo.Category;
import java.util.List;

public interface CategoryDao {
    boolean addCategory(Category c);
    boolean updateCategory(Category c);
    boolean deleteCategory(int cid);
    Category getCategoryById(int cid);
    List<Category> getAllCategories();
}
