package com.servlets;

import com.pojo.CartItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

@WebServlet("/RemoveItemServlet")
public class RemoveItemServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int pid = Integer.parseInt(request.getParameter("pid"));
        HttpSession session = request.getSession();

        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

        if (cartItems != null) {
            Iterator<CartItem> iterator = cartItems.iterator();
            while (iterator.hasNext()) {
                CartItem item = iterator.next();
                if (item.getPid() == pid) {
                    iterator.remove();
                    break;
                }
            }

            // Recalculate grand total after item removal
            double grandTotal = 0.0;
            for (CartItem item : cartItems) {
                grandTotal += item.getPrice() * item.getQuantity();
            }
            session.setAttribute("grandTotal", grandTotal);

            // Update cart list in session
            session.setAttribute("cartItems", cartItems);
        }

        response.sendRedirect("cart.jsp"); // fixed typo here
    }
}
