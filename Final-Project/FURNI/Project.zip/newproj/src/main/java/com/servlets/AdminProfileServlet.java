package com.servlets;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminProfileServlet")
public class AdminProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private dao userDao;

    @Override
    public void init() throws ServletException {
        userDao = new daoimpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 🔐 Check login
        if (session == null || session.getAttribute("loggedInUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        UserInfo sessionUser = (UserInfo) session.getAttribute("loggedInUser");

        // 🔐 Only admins allowed
        if (!"admin".equalsIgnoreCase(sessionUser.getRole())) {
            response.sendRedirect("login.jsp");
            return;
        }

        // 🔄 Get updated profile from DB
        UserInfo admin = userDao.getUserByUsername(sessionUser.getUsername());
        request.setAttribute("admin", admin);

        // 👥 Get list of members added by this admin
        List<UserInfo> addedMembers = userDao.getMembersAddedByAdmin(admin.getUsername());
        request.setAttribute("addedMembers", addedMembers);
        request.setAttribute("memberCount", (addedMembers != null) ? addedMembers.size() : 0);

        // 📄 Forward to JSP
        request.getRequestDispatcher("adminProfile.jsp").forward(request, response);
    }
}
