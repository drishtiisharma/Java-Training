package com.servlets;

import com.pojo.CartItem;
import com.pojo.DBConnection;
import com.pojo.OrderItem;
import com.pojo.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("cartItems") == null) {
            response.sendRedirect("cart.jsp"); // fixed typo from cart..jsp
            return;
        }

        @SuppressWarnings("unchecked")
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

        UserInfo user = (UserInfo) session.getAttribute("loggedInUser");
        if (user == null) {
            request.setAttribute("error", "User not logged in.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        String username = user.getUsername();

        // Billing Info
        String billingName = request.getParameter("billingName");
        String billingAddress = request.getParameter("billingAddress");
        String billingState = request.getParameter("billingState");
        String billingZip = request.getParameter("billingZip");

        String fullAddress = billingName + ", " + billingAddress + ", " + billingState + " - " + billingZip;

        // Payment
        String paymentMethod = request.getParameter("paymentMethod");

        // Recalculate total to ensure accuracy
        double grandTotal = 0.0;
        for (CartItem item : cartItems) {
            grandTotal += item.getPrice() * item.getQuantity();
        }

        Connection conn = null;
        PreparedStatement psOrder = null;
        PreparedStatement psItem = null;
        PreparedStatement psFetchProduct = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // begin transaction

            // Insert into orders
            String sqlOrder = "INSERT INTO orders (username, total_amount, shipping_address, payment_method) VALUES (?, ?, ?, ?)";
            psOrder = conn.prepareStatement(sqlOrder, Statement.RETURN_GENERATED_KEYS);
            psOrder.setString(1, username);
            psOrder.setDouble(2, grandTotal);
            psOrder.setString(3, fullAddress);
            psOrder.setString(4, paymentMethod);
            psOrder.executeUpdate();

            rs = psOrder.getGeneratedKeys();
            int orderId = 0;
            if (rs.next()) {
                orderId = rs.getInt(1);
            }

            // Insert into order_items
            String sqlItem = "INSERT INTO order_items (order_id, pid, quantity, price) VALUES (?, ?, ?, ?)";
            psItem = conn.prepareStatement(sqlItem);

            for (CartItem item : cartItems) {
                psItem.setInt(1, orderId);
                psItem.setInt(2, item.getPid());
                psItem.setInt(3, item.getQuantity());
                psItem.setDouble(4, item.getPrice());
                psItem.addBatch();
            }

            psItem.executeBatch();

            // Prepare order items for display
            List<OrderItem> orderItems = new ArrayList<>();
            String productQuery = "SELECT pname, image_url FROM product WHERE pid = ?";
            psFetchProduct = conn.prepareStatement(productQuery);

            for (CartItem item : cartItems) {
                psFetchProduct.setInt(1, item.getPid());
                ResultSet rsProd = psFetchProduct.executeQuery();

                OrderItem o = new OrderItem();
                o.setOrderId(orderId);
                o.setPid(item.getPid());
                o.setQuantity(item.getQuantity());
                o.setPrice(item.getPrice());

                if (rsProd.next()) {
                    o.setProductName(rsProd.getString("pname"));
                    o.setImageUrl(rsProd.getString("image_url"));
                }

                orderItems.add(o);
                rsProd.close();
            }

            conn.commit(); // commit transaction

            // Clear cart session data
            session.removeAttribute("cartItems");
            session.removeAttribute("grandTotal");

            // Set order info for success page
            request.setAttribute("orderId", orderId);
            request.setAttribute("billingName", billingName);
            request.setAttribute("billingAddress", billingAddress);
            request.setAttribute("billingState", billingState);
            request.setAttribute("billingZip", billingZip);
            request.setAttribute("billingEmail", user.getEmail());
            request.setAttribute("billingPhone", user.getPhone());
            request.setAttribute("paymentMethod", paymentMethod);
            request.setAttribute("orderItems", orderItems);
            request.setAttribute("totalAmount", grandTotal);

            request.getRequestDispatcher("order-success.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            request.setAttribute("error", "Order failed: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);

        } finally {
            try {
                if (rs != null) rs.close();
                if (psOrder != null) psOrder.close();
                if (psItem != null) psItem.close();
                if (psFetchProduct != null) psFetchProduct.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
