package com.servlets;

import com.pojo.CartItem;
import com.pojo.DBConnection;
import com.pojo.Product;
import com.daoimpl.ProductDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/BuyNowServlet")
public class BuyNowServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        // Parse product id and quantity from query params
        String pidParam = request.getParameter("pid");
        String quantityParam = request.getParameter("quantity");

        if (pidParam == null || pidParam.isEmpty()) {
            response.sendRedirect("shop.jsp");  // or product listing page
            return;
        }

        int pid = 0;
        int quantity = 1; // default quantity
        try {
            pid = Integer.parseInt(pidParam);
            if (quantityParam != null && !quantityParam.isEmpty()) {
                quantity = Integer.parseInt(quantityParam);
                if (quantity < 1) quantity = 1;
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("shop.jsp");
            return;
        }

        // Fetch product details from DB
        ProductDaoImpl productDao = new ProductDaoImpl(DBConnection.getConnection());
        Product product = productDao.getProductById(pid);
        if (product == null) {
            response.sendRedirect("shop.jsp");
            return;
        }

        // Create a new cart list with only this product
        List<CartItem> cartItems = new ArrayList<>();
        CartItem cartItem = new CartItem();
        cartItem.setPid(product.getPid());
        cartItem.setPname(product.getPname());
        cartItem.setPrice(product.getPrice());
        cartItem.setQuantity(quantity);
        cartItem.setImageUrl(product.getImage_url());
        cartItems.add(cartItem);

        // Replace any existing cart with this new one (only buy now product)
        session.setAttribute("cartItems", cartItems);

        // Redirect directly to checkout page
        response.sendRedirect("checkout.jsp");
    }
}
