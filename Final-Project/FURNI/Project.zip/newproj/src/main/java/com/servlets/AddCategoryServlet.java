package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.dao.CategoryDao;
import com.daoimpl.CategoryDaoImpl;
import com.pojo.Category;
import com.pojo.DBConnection;

@WebServlet("/AddCategory")
public class AddCategoryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int cid = Integer.parseInt(request.getParameter("cid"));
        String name = request.getParameter("category_name");
        String desc = request.getParameter("category_description");

        Category c = new Category(cid, name, desc);
        CategoryDao dao = new CategoryDaoImpl(DBConnection.getConnection());

        if (dao.addCategory(c) == true) {
            response.sendRedirect("CategoryServlet");
        } else {
            response.sendRedirect("add-category.jsp?error=1");
        }
    }
}
