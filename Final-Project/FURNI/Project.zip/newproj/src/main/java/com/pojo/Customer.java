package com.pojo;

public class Customer {
    private String username;
    private String password;
    private String email;
    private String phone;
    private String address;
    private String status;   // from customer_meta
    private String notes;    // from customer_meta
    private String image;    // Added for image URL
    private int customer_id;

    public int getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(int customer_id) {
        this.customer_id = customer_id;
    }

    // Default constructor
    public Customer() {
        super();
    }

    // Constructor with all fields
    public Customer(String username, String password, String email, String phone, String address, String image) {
        super();
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.image = image;   // Initialize image field
    }

    public Customer(String username, String password, String email, String phone, String address, String status,
			String notes, String image) {
		super();
		this.username = username;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.status = status;
		this.notes = notes;
		this.image = image;
	}

	// Constructor with status and notes (for customer_meta)
    public Customer(String status, String notes) {
        super();
        this.status = status;
        this.notes = notes;
    }

    // Getters and setters for all fields...
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
