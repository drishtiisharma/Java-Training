package com.servlets;

import com.dao.CustomerDao;
import com.daoimpl.CustomerDaoImpl;
import com.pojo.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

@WebServlet("/AdminCustomerServlet")
public class AdminCustomerServlet extends HttpServlet {

    private CustomerDao customerDao;

    @Override
    public void init() throws ServletException {
        super.init();
        customerDao = new CustomerDaoImpl(); // Initialize the DAO implementation
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve the search query from the request
        String search = request.getParameter("search");

        // Perform the search or get all customers based on the search query
        List<Customer> customerList;
        if (search != null && !search.trim().isEmpty()) {
            customerList = customerDao.searchCustomers(search.trim()); // Call search method from DAO
        } else {
            customerList = customerDao.getAllCustomers(); // Get all customers
        }

        // Initialize Maps for additional customer data (orders, revenue, etc.)
        Map<String, Integer> orderCountMap = new HashMap<>();
        Map<String, Double> revenueMap = new HashMap<>();
        Map<String, String> lastOrderDateMap = new HashMap<>();
        Map<String, String> customerSinceMap = new HashMap<>();
        Map<String, String> statusMap = new HashMap<>();

        // Populate maps with customer-related data
        for (Customer c : customerList) {
            String username = c.getUsername();
            orderCountMap.put(username, customerDao.getOrderCountByUsername(username));
            revenueMap.put(username, customerDao.getTotalSpentByUsername(username));
            lastOrderDateMap.put(username, customerDao.getLastOrderDateByUsername(username));
            customerSinceMap.put(username, customerDao.getCustomerSinceDateByUsername(username));
            statusMap.put(username, customerDao.getCustomerStatus(username)); // Get customer status from DAO
        }

        // Set the customer-related data as request attributes for use in JSP
        request.setAttribute("customerList", customerList);
        request.setAttribute("orderCountMap", orderCountMap);
        request.setAttribute("revenueMap", revenueMap);
        request.setAttribute("lastOrderDateMap", lastOrderDateMap);
        request.setAttribute("customerSinceMap", customerSinceMap);
        request.setAttribute("statusMap", statusMap);

        // Set the active tab for navbar highlighting
        
        request.getSession().setAttribute("activePage", "customer");


        // Forward the request to the customer.jsp page
        request.getRequestDispatcher("customer.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle search or other POST actions
        doGet(request, response); // Call doGet() to handle the request similarly for POST
    }
}
