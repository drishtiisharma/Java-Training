package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.CategoryDao;
import com.daoimpl.CategoryDaoImpl;
import com.pojo.Category;
import com.pojo.DBConnection;

@WebServlet("/EditCategoryServlet")
public class EditCategoryServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int cid = Integer.parseInt(request.getParameter("cid"));
            String name = request.getParameter("category_name");
            String description = request.getParameter("category_description");

            Category category = new Category(cid, name, description);
            CategoryDao dao = new CategoryDaoImpl(DBConnection.getConnection());

            boolean isUpdated = dao.updateCategory(category);

            if (isUpdated) {
                response.sendRedirect("CategoryServlet");
            } else {
                response.sendRedirect("edit-category.jsp?cid=" + cid + "&error=1");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("edit-category.jsp?cid=" + request.getParameter("cid") + "&error=1");
        }
    }
}
