package com.daoimpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.dao.dao;
import com.pojo.UserInfo;

public class daoimpl implements dao {

    Connection con = null;

    public daoimpl() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/furni", "root", "root"
            );
            System.out.println("Database connected successfully");
        } catch (Exception e) {
            System.out.println("❌ Error loading JDBC driver or connecting to DB");
            e.printStackTrace();
        }
    }

	@Override
    public boolean addUser(UserInfo u) {
        try {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO customer (username, password, email, phone, address) VALUES (?, ?, ?, ?, ?)"
            );
            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getPhone());
            ps.setString(5, u.getAddress());

            int x = ps.executeUpdate();

            if (x > 0) {
                ps = con.prepareStatement("INSERT INTO user (username, password, role) VALUES (?, ?, ?)");
                ps.setString(1, u.getUsername());
                ps.setString(2, u.getPassword());
                ps.setString(3, u.getRole());

                x = ps.executeUpdate();
                return x > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateUser(UserInfo user) {
        try {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE customer SET username=?, password=?, phone=?, address=? WHERE email=?"
            );

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getAddress());
            ps.setString(5, user.getEmail());

            int x = ps.executeUpdate();
            System.out.println("Rows updated: " + x);
            return x > 0;
        } catch (Exception e) {
            System.out.println("❌ Error updating user:");
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteUser(String email) {
        try {
            PreparedStatement ps = con.prepareStatement("DELETE customer, user\r\n"
            		+ "FROM customer\r\n"
            		+ "INNER JOIN user ON customer.email = user.email\r\n"
            		+ "WHERE user.email = ?\r\n"
            		+ "");
            ps.setString(1, email);

            int x = ps.executeUpdate();
            System.out.println("Rows deleted: " + x);
            return x > 0;
        } catch (Exception e) {
            System.out.println("❌ Error deleting user:");
            e.printStackTrace();
            return false;
        }
    }



    @Override
    public List<UserInfo> getAllUsers() {
        List<UserInfo> userList = new ArrayList<>();

        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM customer");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                UserInfo user = new UserInfo();
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setPhone(rs.getString("phone"));
                user.setEmail(rs.getString("email"));
                user.setAddress(rs.getString("address"));
                userList.add(user);
            }
        } catch (Exception e) {
            System.out.println("❌ Error fetching user list:");
            e.printStackTrace();
        }

        return userList;
    }

    @Override
    public boolean isUsernameExists(String username) {
        try {
            PreparedStatement ps = con.prepareStatement("SELECT username FROM customer WHERE username = ?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            System.out.println("❌ Error checking username existence:");
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean isEmailExists(String email) {
        try {
            PreparedStatement ps = con.prepareStatement("SELECT email FROM customer WHERE email = ?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            System.out.println("❌ Error checking email existence:");
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public UserInfo getUserByUsername(String username) {
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE username=?");
            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                UserInfo user = new UserInfo();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setImage(rs.getString("image"));
                return user;
            }
        } catch (Exception e) {
            System.out.println("❌ Error fetching user by username:");
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int countMembersAddedBy(String adminUsername) {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM user WHERE added_by = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, adminUsername);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public int countUsersAddedBy(String adminUsername) {
        int count = 0;
        try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM user WHERE created_by = ?")) {
            ps.setString(1, adminUsername);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) count = rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    @Override
    public List<UserInfo> getUsersAddedBy(String adminUsername) {
        List<UserInfo> list = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement("SELECT * FROM user WHERE created_by = ?")) {
            ps.setString(1, adminUsername);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                UserInfo u = new UserInfo();
                u.setUsername(rs.getString("username"));
                u.setRole(rs.getString("role"));
                u.setEmail(rs.getString("email"));
                u.setPhone(rs.getString("phone"));
                u.setAddress(rs.getString("address"));
                list.add(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<UserInfo> getMembersAddedByAdmin(String addedByUsername) {
        List<UserInfo> list = new ArrayList<>();
        String sql = "SELECT * FROM user WHERE added_by = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, addedByUsername);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                UserInfo user = new UserInfo();
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setRole(rs.getString("role"));
                list.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean insertUser(UserInfo user) {
        String sql = "INSERT INTO user (username, email, password, role, phone, address, image, added_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.setString(5, user.getPhone());
            ps.setString(6, user.getAddress());
            ps.setString(7, user.getImage());
            ps.setString(8, user.getAddedBy());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteUserByUsernameAndAddedBy(String username, String addedBy) {
        String sql = "DELETE FROM user WHERE username = ? AND added_by = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, addedBy);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean isEmailExistsinadmin(String email) {
        String sql = "SELECT 1 FROM user WHERE email = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateUserinadmin(UserInfo user) {
        String sql = "UPDATE user SET username=?, email=?, phone=?, address=?, image=? WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getAddress());
            ps.setString(5, user.getImage());
            ps.setInt(6, user.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateUserByEmail(String oldEmail, UserInfo user) {
        String sql = "UPDATE user SET username=?, email=?, phone=?, address=?, image=? WHERE email=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getAddress());
            ps.setString(5, user.getImage());
            ps.setString(6, oldEmail);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updatePasswordById(int id, String newPassword) {
        String sql = "UPDATE user SET password=? WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateUserSecurity(int id, String question, String answer) {
        String sql = "UPDATE user SET security_question = ?, security_answer = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, question);
            ps.setString(2, answer);
            ps.setInt(3, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
  
    }
    
    @Override
    public boolean updateSecurityQuestion(int userId, String question, String answer) {
        String sql = "UPDATE user SET security_question = ?, security_answer = ? WHERE id = ?";
        try (
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, question);
            stmt.setString(2, answer);
            stmt.setInt(3, userId);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
        @Override
        public UserInfo getUserByLoginCredential(String credential, String password) {
            Connection conn = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            UserInfo user = null;

            try {
               
                String sql = "SELECT * FROM user WHERE (username = ? OR email = ?) AND password = ?";
                ps = con.prepareStatement(sql);
                ps.setString(1, credential);
                ps.setString(2, credential);
                ps.setString(3, password);
                rs = ps.executeQuery();

                if (rs.next()) {
                    user = new UserInfo();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setEmail(rs.getString("email"));
                    user.setPassword(rs.getString("password"));
                    user.setRole(rs.getString("role"));
                    user.setPhone(rs.getString("phone"));
                    user.setAddress(rs.getString("address"));
                    user.setImage(rs.getString("image"));
                    user.setSecurityQuestion(rs.getString("security_question"));
                    user.setSecurityAnswer(rs.getString("security_answer"));
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (ps != null) ps.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return user;
        }

        public boolean registerCustomer(UserInfo user) {
            PreparedStatement psCustomer = null;
            PreparedStatement psUser = null;
            boolean result = false;

            try {
                con.setAutoCommit(false); // Begin transaction

                // Insert into customer table
                String customerSql = "INSERT INTO customer (username, email, password, phone, address, image, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                psCustomer = con.prepareStatement(customerSql);
                psCustomer.setString(1, user.getUsername());
                psCustomer.setString(2, user.getEmail());
                psCustomer.setString(3, user.getPassword());
                psCustomer.setString(4, user.getPhone());
                psCustomer.setString(5, user.getAddress());
                psCustomer.setString(6, user.getImage());
                psCustomer.setTimestamp(7, new Timestamp(System.currentTimeMillis())); // set created_at timestamp
                psCustomer.setTimestamp(8, new Timestamp(System.currentTimeMillis())); // set updated_at timestamp
                psCustomer.executeUpdate();

                // Insert into user table
                String userSql = "INSERT INTO user (username, email, password, role, phone, address, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                psUser = con.prepareStatement(userSql);
                psUser.setString(1, user.getUsername());
                psUser.setString(2, user.getEmail());
                psUser.setString(3, user.getPassword());
                psUser.setString(4, "customer"); // role
                psUser.setString(5, user.getPhone());
                psUser.setString(6, user.getAddress());
                psUser.setString(7, user.getImage());
                psUser.setTimestamp(8, new Timestamp(System.currentTimeMillis())); // created_at timestamp
                psUser.executeUpdate();

                con.commit(); // Commit the transaction

                result = true;
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    if (con != null) con.rollback(); // Rollback on failure
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            } finally {
                try {
                    if (psCustomer != null) psCustomer.close();
                    if (psUser != null) psUser.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            return result;
        }
        public boolean updateCustomerProfile(UserInfo customer) {
            String query = "UPDATE user SET username = ?, email = ?, password = ?, phone = ?, address = ?, image = ? WHERE id = ?";
            
            try ( // Assume DBConnection is a class that provides DB connection
                 PreparedStatement stmt = con.prepareStatement(query)) {

                stmt.setString(1, customer.getUsername());
                stmt.setString(2, customer.getEmail());
                stmt.setString(3, customer.getPassword());
                stmt.setString(4, customer.getPhone());
                stmt.setString(5, customer.getAddress());
                stmt.setString(6, customer.getImage());  // Set the image path
                stmt.setInt(7, customer.getId()); // Assuming 'id' is the primary key of the user

                int rowsUpdated = stmt.executeUpdate();
                return rowsUpdated > 0;  // Return true if the update was successful
            } catch (SQLException e) {
                e.printStackTrace();
                return false; // Return false if there was an exception
            }
        }
      
        @Override
        public boolean updateUserProfile(int userId, String phone, String address, String securityQuestion, String securityAnswer) {
            String sql = "UPDATE user SET phone = ?, address = ?, security_question = ?, security_answer = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, phone);
                ps.setString(2, address);
                ps.setString(3, securityQuestion);
                ps.setString(4, securityAnswer);
                ps.setInt(5, userId);
                int rowsAffected = ps.executeUpdate();
                return rowsAffected > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        public boolean updateUserProfile(int id, String username, String email, String phone, String address, String securityQuestion, String securityAnswer, String imagePath) {
            String sql = "UPDATE user SET username=?, email=?, phone=?, address=?, security_question=?, security_answer=?, image=?, updated_at=CURRENT_TIMESTAMP WHERE id=?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, username);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, address);
                ps.setString(5, securityQuestion);
                ps.setString(6, securityAnswer);
                ps.setString(7, imagePath);
                ps.setInt(8, id);

                int updated = ps.executeUpdate();
                return updated > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }
        public boolean updatePasswordAndSecurity(int id, String password, String question, String answer) {
            StringBuilder sql = new StringBuilder("UPDATE user SET password = ?");
            List<Object> params = new ArrayList<>();

            params.add(password); // First param

            if (question != null && !question.trim().isEmpty()) {
                sql.append(", security_question = ?");
                params.add(question.trim());
            }

            if (answer != null && !answer.trim().isEmpty()) {
                sql.append(", security_answer = ?");
                params.add(answer.trim());
            }

            sql.append(" WHERE id = ?");
            params.add(id);

            try (
                 PreparedStatement ps = con.prepareStatement(sql.toString())) {

                for (int i = 0; i < params.size(); i++) {
                    ps.setObject(i + 1, params.get(i));
                }

                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        public UserInfo getUserById(int id) {
            UserInfo user = null;

            String sql = "SELECT * FROM user WHERE id = ?";
            try (
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        user = new UserInfo();
                        user.setId(rs.getInt("id"));
                        user.setUsername(rs.getString("username"));
                        user.setEmail(rs.getString("email"));
                        user.setPassword(rs.getString("password"));
                        user.setPhone(rs.getString("phone"));
                        user.setAddress(rs.getString("address"));
                        user.setImage(rs.getString("image"));
                        user.setRole(rs.getString("role"));
                        user.setSecurityQuestion(rs.getString("security_question"));
                        user.setSecurityAnswer(rs.getString("security_answer"));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return user;
        }
        @Override
        public boolean updatePassword(String email, String newPassword) {
            try {
                // Step 1: Update password in customer table
                PreparedStatement ps = con.prepareStatement(
                    "UPDATE customer SET password = ? WHERE email = ?"
                );
                ps.setString(1, newPassword);
                ps.setString(2, email);
                int x = ps.executeUpdate();

                // Step 2: If successful, update password in user table using email
                if (x > 0) {
                    ps = con.prepareStatement(
                        "UPDATE user SET password = ? WHERE email = ?"
                    );
                    ps.setString(1, newPassword);
                    ps.setString(2, email);
                    x = ps.executeUpdate();
                    return x > 0;
                }

                return false; // if customer update failed
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        public boolean setSecurityQuestionAnswer(int id, String question, String answer) {
            String sql = "UPDATE user SET security_question = ?, security_answer = ? WHERE id = ?";

            try (
                 PreparedStatement ps = con.prepareStatement(sql)) {

                System.out.println("Executing SQL for user ID: " + id);
                System.out.println("Question: " + question);
                System.out.println("Answer: " + answer);

                ps.setString(1, question);
                ps.setString(2, answer);
                ps.setInt(3, id);

                int result = ps.executeUpdate();
                System.out.println("Update result (rows affected): " + result);

                return result > 0;

            } catch (Exception e) {
                System.err.println("Error during security question update:");
                e.printStackTrace();
                return false;
            }
        }
}




