package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

@WebServlet("/ChangeNewPasswordServlet")
public class ChangeNewPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private daoimpl userDao = new daoimpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession();
        UserInfo user = (UserInfo) session.getAttribute("loggedInUser");

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        // Check if old password matches
        if (!user.getPassword().equals(oldPassword)) {
            request.setAttribute("error", "Old password is incorrect.");
            request.getRequestDispatcher("changenewpassword.jsp").forward(request, response);
            return;
        }

        // Check if new passwords match
        if (!newPassword.equals(confirmPassword)) {
            request.setAttribute("error", "New passwords do not match.");
            request.getRequestDispatcher("changenewpassword.jsp").forward(request, response);
            return;
        }

        // Update password in database
        boolean updated = userDao.updatePassword(user.getEmail(), newPassword);
        if (updated) {
            user.setPassword(newPassword);
            session.setAttribute("loggedInUser", user);
            request.setAttribute("msg", "Password changed successfully.");
            request.getRequestDispatcher("editcustomernew.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Failed to update password.");
            request.getRequestDispatcher("changenewpassword.jsp").forward(request, response);
        }
    }
}
