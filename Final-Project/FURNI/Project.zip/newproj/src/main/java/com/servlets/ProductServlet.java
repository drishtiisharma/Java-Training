package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.pojo.Product;
import com.daoimpl.ProductDaoImpl;
import com.pojo.DBConnection;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pidStr = request.getParameter("pid");

        if (pidStr == null || pidStr.trim().isEmpty()) {
            request.setAttribute("error", "Product ID is missing.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        try {
            int pid = Integer.parseInt(pidStr);

            ProductDaoImpl dao = new ProductDaoImpl(DBConnection.getConnection());
            Product product = dao.getProductById(pid);

            if (product != null) {
                request.setAttribute("product", product);
                request.getRequestDispatcher("product-details.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Product not found!");
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid product ID format.");
            request.getRequestDispatcher("error.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace(); // Logs to server console
            request.setAttribute("error", "An internal error occurred: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); // Forward POST requests to GET logic
    }
}
