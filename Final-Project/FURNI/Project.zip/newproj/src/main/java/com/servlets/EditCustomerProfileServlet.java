package com.servlets;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

@WebServlet("/EditCustomerProfileServlet")
@MultipartConfig
public class EditCustomerProfileServlet extends HttpServlet {
    private dao userDao;

    // Define folder where images will be saved (update the path as per your environment)
    private static final String IMAGE_UPLOAD_DIR = "C:/Users/HP/OneDrive/Desktop/newproj/newproj/src/main/webapp/images/";
    @Override
    public void init() {
        userDao = new daoimpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve user from session
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        UserInfo user = (UserInfo) session.getAttribute("loggedInUser");

        // Get form parameters
        String idStr = request.getParameter("id");
        int id = Integer.parseInt(idStr);
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String securityQuestion = request.getParameter("securityQuestion");
        String securityAnswer = request.getParameter("securityAnswer");

        // Handle profile image upload
        Part imagePart = request.getPart("profileImage");
        String imagePath = user.getImage(); // default existing image path

        if (imagePart != null && imagePart.getSize() > 0) {
            String fileName = Paths.get(imagePart.getSubmittedFileName()).getFileName().toString();

            // Create upload dir if not exists
            File uploadDir = new File(IMAGE_UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // Save file on server
            imagePath = "images/" + fileName; // relative path to use in your app, adjust accordingly
            String fullSavePath = uploadDir + File.separator + fileName;
            imagePart.write(fullSavePath);
        }

        // Update user object
        user.setUsername(username);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);
        user.setSecurityQuestion(securityQuestion);
        user.setSecurityAnswer(securityAnswer);
        user.setImage(imagePath);

        // Call DAO to update database record
        boolean updated = userDao.updateUserProfile(
            id,
            username,
            email,
            phone,
            address,
            securityQuestion,
            securityAnswer,
            imagePath
        );

        if (updated) {
            // Update session user info
            session.setAttribute("MyProfile.jsp", user);
            response.sendRedirect("editProfile.jsp?success=Profile updated successfully.");
        } else {
            response.sendRedirect("editProfile.jsp?error=Failed to update profile.");
        }
    }
}
