package com.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private dao userDao = new daoimpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String credential = request.getParameter("credential");
        String password = request.getParameter("password");

        // ✅ Input Validation
        if (credential == null || credential.trim().isEmpty()) {
            request.setAttribute("error", "Username or Email is required.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        if (password == null || password.trim().isEmpty()) {
            request.setAttribute("error", "Password is required.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        // ✅ Authenticate using DAO
        UserInfo user = userDao.getUserByLoginCredential(credential.trim(), password.trim());

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("loggedInUser", user); // Full object stored
            session.setAttribute("username", user.getUsername()); // For orders

            if ("admin".equalsIgnoreCase(user.getRole())) {
                session.setAttribute("adminUser", user);
                response.sendRedirect("AdminDashboardServlet");
            } else {
                response.sendRedirect("index.jsp");
            }

        } else {
            request.setAttribute("error", "Invalid username/email or password.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
