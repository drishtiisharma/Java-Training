package com.daoimpl;

import com.dao.CustomerDao;
import com.pojo.Customer;
import com.pojo.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDaoImpl implements CustomerDao {

    private Connection conn;

    // Constructor for initializing the database connection
    public CustomerDaoImpl() {
        try {
            this.conn = DBConnection.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Constructor for using an existing connection (e.g., for testing or flexibility)
    public CustomerDaoImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public Customer getCustomerByUsername(String username) {
        String sql = "SELECT username, password, email, phone, address, image FROM customer WHERE username = ?";
        Customer customer = null;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    customer = new Customer(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address"),
                        rs.getString("image")  // Get image path from the DB
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customer;
    }

    

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT username, email, phone, address, image FROM customer ORDER BY username ASC";

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Customer c = new Customer();
                c.setUsername(rs.getString("username"));
                c.setEmail(rs.getString("email"));
                c.setPhone(rs.getString("phone"));
                c.setAddress(rs.getString("address"));
                c.setImage(rs.getString("image"));  // Fetch the image path
                list.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public List<Customer> getRecentCustomers(int limit) {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT username, email, phone, address, image FROM customer ORDER BY created_at DESC LIMIT ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, limit);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Customer customer = new Customer();
                    customer.setUsername(rs.getString("username"));
                    customer.setEmail(rs.getString("email"));
                    customer.setPhone(rs.getString("phone"));
                    customer.setAddress(rs.getString("address"));
                    customer.setImage(rs.getString("image"));  // Fetch the image path
                    list.add(customer);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public String getCustomerStatus(String username) {
        String sql = "SELECT status FROM customer_meta WHERE customer_id = (SELECT customer_id FROM customer WHERE username = ?)";
        String status = "Active";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    status = rs.getString("status");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    @Override
    public boolean updateCustomerStatus(String username, String newStatus) {
        String sql = "UPDATE customer_meta SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE customer_id = (SELECT customer_id FROM customer WHERE username = ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setString(2, username);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Additional methods for customer management (Order details)
    @Override
    public int getOrderCountByUsername(String username) {
        String sql = "SELECT COUNT(*) FROM orders WHERE username = ?";
        int count = 0;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }

    @Override
    public double getTotalSpentByUsername(String username) {
        String sql = "SELECT SUM(total_amount) FROM orders WHERE username = ?";
        double totalSpent = 0.0;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    totalSpent = rs.getDouble(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalSpent;
    }

    @Override
    public String getLastOrderDateByUsername(String username) {
        String sql = "SELECT MAX(order_date) FROM orders WHERE username = ?";
        String lastOrderDate = null;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    lastOrderDate = rs.getString(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lastOrderDate != null ? lastOrderDate : "No orders yet";
    }

    @Override
    public String getCustomerSinceDateByUsername(String username) {
        String sql = "SELECT MIN(created_at) FROM customer WHERE username = ?";
        String customerSince = null;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    customerSince = rs.getString(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerSince != null ? customerSince : "Unknown";
    }
   

        // Implementing the getCustomerStatusByUsername method
        @Override
        public String getCustomerStatusByUsername(String username) {
            String sql = "SELECT status FROM customer_meta WHERE customer_id = (SELECT customer_id FROM customer WHERE username = ?)";
            String status = "Active";  // Default status

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        status = rs.getString("status");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return status;
        }
        @Override
        public List<Customer> searchCustomers(String keyword) {
            List<Customer> list = new ArrayList<>();
            String sql = "SELECT username, email, phone, address, image FROM customer " +
                         "WHERE username LIKE ? OR email LIKE ?";

            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                String like = "%" + keyword + "%";
                pstmt.setString(1, like);
                pstmt.setString(2, like);

                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        Customer c = new Customer();
                        c.setUsername(rs.getString("username"));
                        c.setEmail(rs.getString("email"));
                        c.setPhone(rs.getString("phone"));
                        c.setAddress(rs.getString("address"));
                        c.setImage(rs.getString("image"));
                        list.add(c);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return list;
        }

     // Updates only security question and answer
        public boolean setSecurityQuestionAnswer(int id, String question, String answer) {
            String sql = "UPDATE user SET security_question = ?, security_answer = ? WHERE id = ?";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, question);
                ps.setString(2, answer);
                ps.setInt(3, id);

                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }


        public boolean updatePasswordAndSecurity(int id, String password, String question, String answer) {
            StringBuilder sql = new StringBuilder("UPDATE user SET password=?");
            if (question != null && !question.isEmpty()) sql.append(", security_question=?");
            if (answer != null && !answer.isEmpty()) sql.append(", security_answer=?");
            sql.append(" WHERE id=?");

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql.toString())) {

                int i = 1;
                ps.setString(i++, password);
                if (question != null && !question.isEmpty()) ps.setString(i++, question);
                if (answer != null && !answer.isEmpty()) ps.setString(i++, answer);
                ps.setInt(i, id);
                return ps.executeUpdate() > 0;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        @Override
        public boolean updateCustomer(Customer customer) {
            boolean updated = false;
            String sql = "UPDATE customer SET username=?, phone=?, email=?, password=?, address=?, image=?, updated_at=NOW() WHERE customer_id=?";

            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, customer.getUsername());
                ps.setString(2, customer.getPhone());
                ps.setString(3, customer.getEmail());
                ps.setString(4, customer.getPassword());
                ps.setString(5, customer.getAddress());
                ps.setString(6, customer.getImage());
                ps.setInt(7, customer.getCustomer_id());

                updated = ps.executeUpdate() > 0;
            } catch (Exception e) {
                e.printStackTrace();
            }

            return updated;
        }


}
