package com.dao;
import java.util.Map;

import com.pojo.Admin;
import com.pojo.Customer;
import com.pojo.Order;
import com.pojo.Product;
import java.util.List;

public interface AdminDao {

    // Admin Authentication
    Admin getAdminByEmailAndPassword(String email, String password);

    // Dashboard Stats
    int getTotalUsers();
    int getTotalProducts();
    int getTotalOrders();
    double getTotalRevenue();

    // Dashboard Lists
    List<Customer> getRecentCustomers();
    List<Order> getRecentOrders();
    List<Product> getLowStockProducts();
    List<Customer> getAllCustomers();
    Map<String, Integer> getOrderCountsPerCustomer();
    Map<String, Double> getRevenuePerCustomer();
    Map<String, String> getLastOrderDatePerCustomer();
    Map<String, String> getCustomerSinceDate();
    Map<String, String> getCustomerNotes();
    Map<String, String> getCustomerStatus();



}
