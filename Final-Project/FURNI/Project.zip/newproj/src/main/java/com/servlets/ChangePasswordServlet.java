package com.servlets;

import com.daoimpl.daoimpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        try {
            // Retrieve parameters
            int id = Integer.parseInt(req.getParameter("id"));
            String newPassword = req.getParameter("newPassword");
            String question = req.getParameter("securityQuestion");
            String answer = req.getParameter("securityAnswer");

            // Validate new password
            if (newPassword == null || newPassword.trim().isEmpty()) {
                res.sendRedirect("verify-security.jsp?id=" + id + "&step=verified&error=Password is required");
                return;
            }

            // Trim values to avoid null/space errors
            newPassword = newPassword.trim();
            if (question != null) question = question.trim();
            if (answer != null) answer = answer.trim();

            daoimpl dao = new daoimpl();

            // Update password and optionally security question/answer
            boolean success = dao.updatePasswordAndSecurity(id, newPassword, question, answer);

            if (success) {
                res.sendRedirect("editProfile.jsp?success=Password updated successfully");
            } else {
                res.sendRedirect("verify-security.jsp?id=" + id + "&step=verified&error=Update failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("verify-security.jsp?error=Unexpected error occurred");
        }
    }
}
