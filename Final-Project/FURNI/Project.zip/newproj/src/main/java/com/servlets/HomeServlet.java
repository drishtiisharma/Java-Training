package com.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.daoimpl.ProductDaoImpl;
import com.pojo.Product;
import com.pojo.DBConnection;

@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProductDaoImpl dao = new ProductDaoImpl(DBConnection.getConnection());

        List<Product> randomProducts = dao.getRandomProducts(6); // get 6 random products
        request.setAttribute("randomProducts", randomProducts);

        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
