package com.servlets;

import com.dao.OrderDao;
import com.daoimpl.OrderDaoImpl;
import com.pojo.DBConnection;
import com.pojo.Order;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/AdminManageOrdersServlet")
public class AdminManageOrdersServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try (Connection conn = DBConnection.getConnection()) {
            OrderDao dao = new OrderDaoImpl(conn);
            List<Order> orderList = dao.getAllOrders();

            request.setAttribute("orderList", orderList);
            request.setAttribute("totalOrders", dao.getTotalOrders());
            request.setAttribute("pendingOrders", dao.getPendingOrders());
            request.setAttribute("processingOrders", dao.getProcessingOrders());
            request.setAttribute("deliveredOrders", dao.getDeliveredOrders());
         // In AdminManageOrdersServlet.java
            request.getSession().setAttribute("activePage", "orders");
            request.getRequestDispatcher("admin-ordermanager.jsp").forward(request, response);

           
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
