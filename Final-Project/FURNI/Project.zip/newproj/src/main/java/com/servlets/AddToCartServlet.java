package com.servlets;

import com.pojo.CartItem;
import com.pojo.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int pid = Integer.parseInt(request.getParameter("pid"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        HttpSession session = request.getSession();
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

        if (cartItems == null) {
            cartItems = new ArrayList<>();
        }

        boolean found = false;

        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT pname, price, image_url, quantity AS stock FROM product WHERE pid = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, pid);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int availableStock = rs.getInt("stock");

                for (CartItem item : cartItems) {
                    if (item.getPid() == pid) {
                        int newQty = item.getQuantity() + quantity;
                        if (newQty <= availableStock) {
                            item.setQuantity(newQty);
                        } else {
                            item.setQuantity(availableStock); // Cap to available stock
                        }
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    CartItem item = new CartItem();
                    item.setPid(pid);
                    item.setPname(rs.getString("pname"));
                    item.setPrice(rs.getDouble("price"));
                    item.setQuantity(Math.min(quantity, availableStock));
                    item.setImageUrl(rs.getString("image_url"));
                    item.setStock(availableStock); // Store stock info for later use
                    cartItems.add(item);
                }
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        session.setAttribute("cartItems", cartItems);

        // Recalculate grand total
        double grandTotal = 0;
        for (CartItem item : cartItems) {
            grandTotal += item.getPrice() * item.getQuantity();
        }
        session.setAttribute("grandTotal", grandTotal);

        // For AJAX: return success message (not redirect)
        response.setContentType("text/plain");
        response.sendRedirect("ShopServlet");    }
}
