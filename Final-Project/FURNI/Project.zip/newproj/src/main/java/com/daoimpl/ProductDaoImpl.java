package com.daoimpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.dao.ProductDao;
import com.pojo.Product;

public class ProductDaoImpl implements ProductDao {
    private Connection con;

    public ProductDaoImpl(Connection con) {
        this.con = con;
    }

    // Add Product
    public boolean addProduct(Product p) {
        String sql = "INSERT INTO product (pname, description, price, quantity, image_url, cid) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getPname());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrice());
            ps.setInt(4, p.getQuantity());
            ps.setString(5, p.getImage_url());
            ps.setInt(6, p.getCid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update Product
    @Override
    public boolean updateProduct(Product p) {
        String sql = "UPDATE product SET pname = ?, description = ?, price = ?, quantity = ?, image_url = ?, cid = ? WHERE pid = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getPname());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrice());
            ps.setInt(4, p.getQuantity());
            ps.setString(5, p.getImage_url());
            ps.setInt(6, p.getCid());
            ps.setInt(7, p.getPid());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete Product
    @Override
    public boolean deleteProduct(int pid) {
        String sql = "DELETE FROM product WHERE pid = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, pid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get Product by ID
    @Override
    public Product getProductById(int pid) {
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE p.pid = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, pid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return extractProduct(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Get All Products
    @Override
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(extractProduct(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Get Products by Category
    @Override
    public List<Product> getProductsByCategory(int cid) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE p.cid = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, cid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(extractProduct(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Search Product by Name
    @Override
    public List<Product> searchProductsByName(String query) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE p.pname LIKE ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + query + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(extractProduct(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Search by Name + Category
    @Override
    public List<Product> searchProductsByNameAndCategory(String query, int cid) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE p.pname LIKE ? AND p.cid = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + query + "%");
            ps.setInt(2, cid);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(extractProduct(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Update Quantity
    @Override
    public boolean updateProductQuantity(int pid, int newQty) {
        String sql = "UPDATE product SET quantity = ? WHERE pid = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, newQty);
            ps.setInt(2, pid);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Low Stock Products
    @Override
    public List<Product> getLowStockProducts(int threshold) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE quantity <= ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(extractProduct(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Dashboard Stats
    @Override
    public int getTotalUsers() {
        try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM customer");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int getTotalProducts() {
        try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM product");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int getTotalOrders() {
        try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM orders");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public double getTotalRevenue() {
        try (PreparedStatement ps = con.prepareStatement("SELECT SUM(totalAmount) FROM orders");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    // Utility: Extract product from result set
    private Product extractProduct(ResultSet rs) throws SQLException {
        return new Product(
                rs.getInt("pid"),
                rs.getString("pname"),
                rs.getString("description"),
                rs.getDouble("price"),
                rs.getInt("quantity"),
                rs.getString("image_url"),
                rs.getInt("cid"),
                rs.getString("category_name"),
                rs.getString("category_description")
        );
    }
    @Override
    public List<Product> getFilteredProducts(String keyword, int cid, int offset, int limit) {
        List<Product> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE 1=1");

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND p.pname LIKE ?");
        }
        if (cid > 0) {
            sql.append(" AND p.cid = ?");
        }

        sql.append(" LIMIT ? OFFSET ?");

        try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int i = 1;
            if (keyword != null && !keyword.trim().isEmpty()) {
                ps.setString(i++, "%" + keyword + "%");
            }
            if (cid > 0) {
                ps.setInt(i++, cid);
            }
            ps.setInt(i++, limit);
            ps.setInt(i++, offset);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("pid"),
                    rs.getString("pname"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("image_url"),
                    rs.getInt("cid"),
                    rs.getString("category_name"),
                    rs.getString("category_description")
                );
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
   
    
    @Override
    public List<Product> searchProductsByCategoryAndName(String categoryName, String keyword) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.category_name, c.category_description FROM product p " +
                     "JOIN category c ON p.cid = c.cid " +
                     "WHERE c.category_name = ? AND p.pname LIKE ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, categoryName);
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("pid"),
                    rs.getString("pname"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("image_url"),
                    rs.getInt("cid"),
                    rs.getString("category_name"),
                    rs.getString("category_description")
                );
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }public int getFilteredProductCount(String keyword, int cid) {
        int count = 0;
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM product WHERE 1=1");

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (pname LIKE ? OR description LIKE ?)");
        }
        if (cid > 0) {
            sql.append(" AND cid = ?");
        }

        try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int i = 1;
            if (keyword != null && !keyword.trim().isEmpty()) {
                ps.setString(i++, "%" + keyword + "%");
                ps.setString(i++, "%" + keyword + "%");
            }
            if (cid > 0) {
                ps.setInt(i++, cid);
            }

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }
    @Override
    public List<Product> getFilteredProducts(String keyword, int cid, int offset, int limit, String sort) {
        List<Product> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT p.*, c.category_name, c.category_description FROM product p JOIN category c ON p.cid = c.cid WHERE 1=1");

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (p.pname LIKE ? OR p.description LIKE ?)");
        }
        if (cid > 0) {
            sql.append(" AND p.cid = ?");
        }

        // Sorting logic
        switch (sort) {
            case "price_asc":
                sql.append(" ORDER BY p.price ASC");
                break;
            case "price_desc":
                sql.append(" ORDER BY p.price DESC");
                break;
            case "date_new":
                sql.append(" ORDER BY p.pid DESC");
                break;
            case "date_old":
                sql.append(" ORDER BY p.pid ASC");
                break;
            default:
                sql.append(" ORDER BY p.pname ASC");
        }

        sql.append(" LIMIT ? OFFSET ?");

        try (PreparedStatement ps = con.prepareStatement(sql.toString())) {
            int i = 1;
            if (keyword != null && !keyword.trim().isEmpty()) {
                ps.setString(i++, "%" + keyword + "%");
                ps.setString(i++, "%" + keyword + "%");
            }
            if (cid > 0) {
                ps.setInt(i++, cid);
            }
            ps.setInt(i++, limit);
            ps.setInt(i++, offset);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("pid"),
                    rs.getString("pname"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("image_url"),
                    rs.getInt("cid"),
                    rs.getString("category_name"),
                    rs.getString("category_description")
                );
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public List<Product> getRandomProducts(int count) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM product ORDER BY RAND() LIMIT ?";
        
        try (
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, count);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Product p = new Product();
                p.setPid(rs.getInt("pid"));
                p.setPname(rs.getString("pname"));
                p.setPrice(rs.getDouble("price"));
                p.setImage_url(rs.getString("image_url"));
                products.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return products;
    }



} 
