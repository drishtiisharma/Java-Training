package com.servlets;

import com.daoimpl.OrderDaoImpl;
import com.pojo.OrderItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/CustomerOrderDetailsServlet")
public class CustomerOrderDetailsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));

            Connection con = com.pojo.DBConnection.getConnection();
            OrderDaoImpl dao = new OrderDaoImpl(con);
            List<OrderItem> items = dao.getOrderItemsByOrderId(orderId);

            request.setAttribute("orderId", orderId);
            request.setAttribute("items", items);

            request.getRequestDispatcher("customer-order-details.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Unable to retrieve order details.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
