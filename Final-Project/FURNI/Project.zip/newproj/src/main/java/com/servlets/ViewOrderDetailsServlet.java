package com.servlets;

import com.dao.OrderDao;
import com.daoimpl.OrderDaoImpl;
import com.pojo.DBConnection;
import com.pojo.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;

@WebServlet("/ViewOrderDetailsServlet")
public class ViewOrderDetailsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int orderId = Integer.parseInt(request.getParameter("orderId"));

        try (Connection conn = DBConnection.getConnection()) {
            OrderDao dao = new OrderDaoImpl(conn);
            Order order = dao.getOrderWithItems(orderId);

            if (order != null) {
                request.setAttribute("order", order);
                request.getRequestDispatcher("orderdetailinadmin.jsp").forward(request, response);
            } else {
                response.sendRedirect("admin-ordermanager.jsp?msg=OrderNotFound");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
