package com.servlets;

import com.dao.CustomerDao;
import com.daoimpl.CustomerDaoImpl;
import com.pojo.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;

@WebServlet("/ToggleCustomerStatusServlet")
public class ToggleCustomerStatusServlet extends HttpServlet {

    private CustomerDao customerDao;

    @Override
    public void init() throws ServletException {
        try {
            Connection conn = DBConnection.getConnection();
            customerDao = new CustomerDaoImpl(conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");

        if (username == null || username.trim().isEmpty()) {
            response.sendRedirect("AdminCustomerServlet?error=MissingUsername");
            return;
        }

        try {
            String currentStatus = customerDao.getCustomerStatusByUsername(username);
            String newStatus = "Blocked".equalsIgnoreCase(currentStatus) ? "Active" : "Blocked";

            boolean updated = customerDao.updateCustomerStatus(username, newStatus);

            if (updated) {
                response.sendRedirect("AdminCustomerServlet?statusUpdated=1");
            } else {
                response.sendRedirect("AdminCustomerServlet?statusUpdated=0");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("AdminCustomerServlet?error=ExceptionOccurred");
        }
    }
}
