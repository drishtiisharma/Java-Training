package com.servlets;

import com.dao.OrderDao;
import com.daoimpl.OrderDaoImpl;
import com.pojo.DBConnection;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/UpdateOrderStatusServlet") 
public class UpdateOrderStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int orderId = Integer.parseInt(request.getParameter("orderId"));
        String status = request.getParameter("status");

        OrderDao dao = new OrderDaoImpl(DBConnection.getConnection());
        boolean updated = dao.updateOrderStatus(orderId, status);

        if (updated) {
            response.sendRedirect("AdminManageOrdersServlet?msg=updated");
        } else {
            response.sendRedirect("AdminManageOrdersServlet?msg=fail");
        }
    }

@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
    response.getWriter().write("UpdateOrderStatusServlet is reachable.");
}}

