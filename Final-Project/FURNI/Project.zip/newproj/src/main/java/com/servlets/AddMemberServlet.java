package com.servlets;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/AddMemberServlet")
@MultipartConfig
public class AddMemberServlet extends HttpServlet {
    private dao userDao;

    @Override
    public void init() throws ServletException {
        userDao = new daoimpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        req.getRequestDispatcher("addMember.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        UserInfo admin = (UserInfo) session.getAttribute("loggedInUser");

        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        String role = req.getParameter("role");
        String securityQuestion = req.getParameter("securityQuestion");
        String securityAnswer = req.getParameter("securityAnswer");

        // Handle profile image upload
        Part imagePart = req.getPart("imageFile");
        String fileName = imagePart.getSubmittedFileName();
        String imagePath = null;

        if (fileName != null && !fileName.isEmpty()) {
            String realPath = getServletContext().getRealPath("/images");
            new File(realPath).mkdirs(); // Create images directory if not exists
            imagePath = "images/" + fileName;
            imagePart.write(realPath + File.separator + fileName);
        }

        // Check for email uniqueness
        if (userDao.isEmailExistsinadmin(email)) {
            req.setAttribute("error", "⚠ Email already exists.");
            req.getRequestDispatcher("addMember.jsp").forward(req, resp);
            return;
        }

        // Create and populate UserInfo object
        UserInfo user = new UserInfo();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password); // Consider encrypting in future
        user.setPhone(phone);
        user.setAddress(address);
        user.setRole(role != null ? role : "member"); // default to member
        user.setImage(imagePath);
        user.setSecurityQuestion(securityQuestion);
        user.setSecurityAnswer(securityAnswer);
        user.setAddedBy(admin.getUsername());

        // Insert new user
        boolean result = userDao.insertUser(user);

        if (result) {
            req.setAttribute("msg", "✅ Member added successfully.");
        } else {
            req.setAttribute("error", "❌ Failed to add member.");
        }

        req.getRequestDispatcher("addMember.jsp").forward(req, resp);
    }
}
