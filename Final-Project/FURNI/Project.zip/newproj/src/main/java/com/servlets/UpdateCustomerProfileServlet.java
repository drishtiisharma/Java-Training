package com.servlets;

import com.dao.CustomerDao;
import com.daoimpl.CustomerDaoImpl;
import com.pojo.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/UpdateCustomerProfileServlet")
public class UpdateCustomerProfileServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Customer currentCustomer = (Customer) session.getAttribute("loggedInUser");

        if (currentCustomer == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Get updated values
        String username = request.getParameter("username");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String address = request.getParameter("address");
        String image = request.getParameter("image"); // Or handle multipart image upload separately

        // Update the current customer object
        currentCustomer.setUsername(username);
        currentCustomer.setPhone(phone);
        currentCustomer.setEmail(email);
        currentCustomer.setPassword(password);
        currentCustomer.setAddress(address);
        currentCustomer.setImage(image);

        // Call DAO to update in DB
        CustomerDao dao = new CustomerDaoImpl();
        boolean success = dao.updateCustomer(currentCustomer);

        if (success) {
            session.setAttribute("loggedInUser", currentCustomer); // Update session
            response.sendRedirect("MyProfile.jsp?update=success");
        } else {
            response.sendRedirect("MyProfile.jsp?update=failed");
        }
    }
}
