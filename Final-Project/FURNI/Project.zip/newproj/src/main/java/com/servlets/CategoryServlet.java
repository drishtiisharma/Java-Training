package com.servlets;

import com.dao.CategoryDao;
import com.daoimpl.CategoryDaoImpl;
import com.pojo.Category;
import com.pojo.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            CategoryDao dao = new CategoryDaoImpl(DBConnection.getConnection());
            List<Category> list = dao.getAllCategories();
            request.setAttribute("categoryList", list);
         // In CategoryServlet.java
            request.getSession().setAttribute("activePage", "categories");

            request.getRequestDispatcher("admin-categories.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to fetch categories");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
