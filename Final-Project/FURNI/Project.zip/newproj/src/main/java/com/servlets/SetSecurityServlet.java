package com.servlets;

import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.daoimpl.daoimpl;

@WebServlet("/SetSecurityServlet")
public class SetSecurityServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        try {
            String idParam = req.getParameter("id");
            String question = req.getParameter("securityQuestion");
            String answer = req.getParameter("securityAnswer");

            if (idParam == null || idParam.trim().isEmpty()) {
                res.sendRedirect("verify-security.jsp?error=" + URLEncoder.encode("User ID missing", "UTF-8"));
                return;
            }

            int id = Integer.parseInt(idParam);

            if (question == null || question.trim().isEmpty() ||
                answer == null || answer.trim().isEmpty()) {
                res.sendRedirect("verify-security.jsp?id=" + id +
                        "&error=" + URLEncoder.encode("Question and Answer cannot be empty", "UTF-8"));
                return;
            }

            System.out.println("Attempting to set security question for user ID: " + id);
            System.out.println("Question: " + question);
            System.out.println("Answer: " + answer);

            daoimpl dao = new daoimpl();
            boolean updated = dao.setSecurityQuestionAnswer(id, question.trim(), answer.trim());

            if (updated) {
                res.sendRedirect("verify-security.jsp?id=" + id +
                        "&step=verified&success=" + URLEncoder.encode("Security question set", "UTF-8"));
            } else {
                res.sendRedirect("verify-security.jsp?id=" + id +
                        "&error=" + URLEncoder.encode("Failed to set security question", "UTF-8"));
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
            res.sendRedirect("verify-security.jsp?error=" + URLEncoder.encode("Invalid user ID", "UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("verify-security.jsp?error=" + URLEncoder.encode("Something went wrong", "UTF-8"));
        }
    }
}
