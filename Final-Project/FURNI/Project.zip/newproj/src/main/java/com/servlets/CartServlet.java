package com.servlets;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.pojo.CartItem;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false); // safer session access

        if (session != null) {
            List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

            if (cartItems != null && !cartItems.isEmpty()) {
                for (CartItem item : cartItems) {
                    String paramName = "quantity_" + item.getPid();
                    String qtyStr = request.getParameter(paramName);

                    if (qtyStr != null) {
                        try {
                            int newQty = Integer.parseInt(qtyStr);

                            // Quantity validation
                            if (newQty < 1) newQty = 1;
                            if (newQty > item.getStock()) newQty = item.getStock();

                            item.setQuantity(newQty);
                        } catch (NumberFormatException e) {
                            e.printStackTrace(); // optional: log properly
                        }
                    }
                }

                // Recalculate grand total
                double grandTotal = 0.0;
                for (CartItem item : cartItems) {
                    grandTotal += item.getPrice() * item.getQuantity();
                }

                session.setAttribute("cartItems", cartItems); // updated list
                session.setAttribute("grandTotal", grandTotal); // updated total
            }
        }

        // ✅ Redirect to correct JSP
        response.sendRedirect("cart.jsp");
    }
}
