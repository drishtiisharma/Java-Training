package com.dao;

import java.util.List;
import com.pojo.Product;

public interface ProductDao {
    boolean addProduct(Product p);
    boolean updateProduct(Product p);
    boolean deleteProduct(int pid);
    Product getProductById(int pid);
    List<Product> getAllProducts();
    List<Product> getProductsByCategory(int cid);
    List<Product> searchProductsByName(String query);
    List<Product> searchProductsByNameAndCategory(String query, int cid);
    List<Product> searchProductsByCategoryAndName(String categoryName, String keyword);
    List<Product> getFilteredProducts(String keyword, int cid, int offset, int limit);
    List<Product> getFilteredProducts(String keyword, int cid, int offset, int limit, String sort);
    int getFilteredProductCount(String keyword, int cid);
    boolean updateProductQuantity(int pid, int newQty);
    List<Product> getLowStockProducts(int threshold);
    public List<Product> getRandomProducts(int count);
    // Dashboard
    int getTotalUsers();
    int getTotalProducts();
    int getTotalOrders();
    double getTotalRevenue();
}
