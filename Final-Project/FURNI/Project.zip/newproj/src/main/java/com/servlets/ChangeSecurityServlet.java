package com.servlets;

import com.dao.dao;
import com.daoimpl.daoimpl;
import com.pojo.UserInfo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/ChangeSecurityServlet")
public class ChangeSecurityServlet extends HttpServlet {
    private dao userDao;

    @Override
    public void init() {
        userDao = new daoimpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        UserInfo admin = (UserInfo) session.getAttribute("loggedInUser");

        if (admin == null || !"admin".equalsIgnoreCase(admin.getRole())) {
            response.sendRedirect("login.jsp");
            return;
        }

        String currentPassword = request.getParameter("currentPassword");
        String newQuestion = request.getParameter("newSecurityQuestion");
        String newAnswer = request.getParameter("newSecurityAnswer");

        // If you're storing hashed passwords, use a password-checking method here
        if (!currentPassword.equals(admin.getPassword())) {
            request.setAttribute("error", "Incorrect password. Security question not updated.");
            request.getRequestDispatcher("editProfile.jsp").forward(request, response);
            return;
        }

        boolean updated = userDao.updateSecurityQuestion(admin.getId(), newQuestion, newAnswer);
        if (updated) {
            // Update session object
            admin.setSecurityQuestion(newQuestion);
            admin.setSecurityAnswer(newAnswer);
            session.setAttribute("loggedInUser", admin);

            response.sendRedirect("editProfile.jsp");
        } else {
            request.setAttribute("error", "Something went wrong while updating the security question.");
            request.getRequestDispatcher("editProfile.jsp").forward(request, response);
        }
    }
}
