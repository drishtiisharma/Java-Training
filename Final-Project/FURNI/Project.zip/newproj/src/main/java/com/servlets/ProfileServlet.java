package com.servlets;

import com.dao.CustomerDao;
import com.daoimpl.CustomerDaoImpl;
import com.pojo.Customer;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
    
    // Database connection parameters
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/furni";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "root";
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Get existing session WITHOUT creating new one
        HttpSession session = request.getSession(false);
        
        // Debug logging
        System.out.println("[ProfileServlet] Session ID: " + (session != null ? session.getId() : "null"));
        System.out.println("[ProfileServlet] Session attributes: " + (session != null ? session.getAttributeNames() : "no session"));
        
        if (session == null || session.getAttribute("loggedInUser") == null) {
            System.out.println("[ProfileServlet] No active session - redirecting to login");
            response.sendRedirect(request.getContextPath() + "/login.jsp?reason=session_expired");
            return;
        }
        
        // Get user from session instead of database
        Customer customer = (Customer) session.getAttribute("loggedInUser");
        System.out.println("[ProfileServlet] Found customer in session: " + customer.getUsername());
        
        try {
            // Verify customer data is complete
            if (customer.getUsername() == null || customer.getEmail() == null) {
                System.out.println("[ProfileServlet] Incomplete customer data, fetching from DB");
                Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
                CustomerDao customerDao = new CustomerDaoImpl(conn);
                customer = customerDao.getCustomerByUsername(customer.getUsername());
                conn.close();
                
                if (customer == null) {
                    throw new SQLException("Customer not found in database");
                }
                
                // Update session with fresh data
                session.setAttribute("loggedInUser", customer);
            }
            
            // Set attributes for JSP
            request.setAttribute("customer", customer);
            System.out.println("[ProfileServlet] Forwarding to profile page with customer: " + customer.getUsername());
            
            // Forward to JSP
            request.getRequestDispatcher("/myprofile.jsp").forward(request, response);
            
        } catch (SQLException e) {
            System.err.println("[ProfileServlet] Error: " + e.getMessage());
            e.printStackTrace();
            session.setAttribute("error", "Profile loading failed: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/error.jsp");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}