package com.servlets;

import com.daoimpl.OrderDaoImpl;
import com.pojo.Order;
import com.pojo.UserInfo;
import com.pojo.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/CustomerOrderServlet")
public class CustomerOrderServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedInUser") == null) {
            response.sendRedirect("login.jsp?reason=not_logged_in");
            return;
        }

        UserInfo customer = (UserInfo) session.getAttribute("loggedInUser");

        try (Connection con = DBConnection.getConnection()) {
            OrderDaoImpl orderDao = new OrderDaoImpl(con);
            List<Order> orders = orderDao.getOrdersByUsername(customer.getUsername());

            request.setAttribute("orders", orders);
            request.setAttribute("customer", customer);
            request.getRequestDispatcher("customerorders.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
